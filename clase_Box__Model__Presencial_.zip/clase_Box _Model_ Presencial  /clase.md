# Clase 7 Modelo de Cajas
## Propiedades Modelo de Caja
- display : navegador, lo <a>
- width
- height
/*poner contenido */
- padding
- border
- border-radius
- margin

- box-sizing

## Position
- static
- relative
- absolute
- fixed
- sticky

## z-index